---
name: Truth Court Deep
colors:
  surface: '#131316'
  surface-dim: '#131316'
  surface-bright: '#39393c'
  surface-container-lowest: '#0e0e11'
  surface-container-low: '#1b1b1e'
  surface-container: '#1f1f22'
  surface-container-high: '#2a2a2d'
  surface-container-highest: '#353438'
  on-surface: '#e4e1e6'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e4e1e6'
  inverse-on-surface: '#303033'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#cebdff'
  on-tertiary: '#381385'
  tertiary-container: '#9b7fed'
  on-tertiary-container: '#31057e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#e8ddff'
  tertiary-fixed-dim: '#cebdff'
  on-tertiary-fixed: '#21005e'
  on-tertiary-fixed-variant: '#4f319c'
  background: '#131316'
  on-background: '#e4e1e6'
  surface-variant: '#353438'
typography:
  headline-xl:
    fontFamily: Sora
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  button-text:
    fontFamily: Sora
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1200px
  gutter: 1.5rem
  margin-mobile: 1rem
  stack-sm: 0.5rem
  stack-md: 1.5rem
  stack-lg: 3rem
---

## Brand & Style

This design system embodies a "Court of Truth" aesthetic—a futuristic, high-stakes environment where AI-driven precision meets judicial authority. The personality is authoritative, mysterious, and hyper-focused. It leverages a **Glassmorphic** and **Modern Corporate** hybrid style, utilizing deep layered surfaces and vibrant luminous accents to guide the user's eye toward critical insights.

The visual mood is cinematic and "Dark UI" first, designed to minimize eye strain during intense data interrogation while evoking a sense of powerful, hidden intelligence. Heavy use of background blurs and subtle violet glows creates a sense of infinite digital depth.

## Colors

The palette is anchored in a true-black and charcoal foundation to maximize contrast for the neon accents.

- **Primary (Violet/Purple):** Used for main actions ("Investigate"), focus states, and the primary brand identity. It represents the "Truth" and "Intelligence" layer.
- **Secondary (Emerald):** Reserved for secondary success actions, utility triggers (e.g., PDF Fact-Check), and confirmation states.
- **Neutral/Background:** A gradient from `#0F0F12` to `#1A1A1F` ensures depth. Text primarily uses a muted gray (`#94A3B8`) for body and pure white or lavender-tinted white for headers.
- **Accents:** Vibrant violet glows (`#8B5CF6`) are used sparingly as backdrop filters to suggest "energy" behind the UI panels.

## Typography

The typography strategy emphasizes technical precision and modern elegance. 

- **Headlines:** Sora provides a geometric, futuristic feel with its unique "ink traps" and wide stance. It should be used for major titles and command prompts.
- **Body:** Geist offers a clean, developer-centric aesthetic that ensures readability in data-heavy views. It is highly legible even at small sizes against dark backgrounds.
- **Utility/Labels:** JetBrains Mono is utilized for metadata, "History" links, and technical tags, reinforcing the AI/Code nature of the tool. 

Use lavender-tinted text colors for secondary information to maintain the chromatic theme.

## Layout & Spacing

The design system uses a **Fluid Grid** approach with generous vertical "stack" spacing to allow the atmospheric glows to breathe. 

- **Grid:** 12-column layout for desktop with 24px gutters. On mobile, this collapses to a single column with 16px side margins.
- **Central Focus:** Main interactive elements (search/investigate) are centered with wide horizontal margins to evoke a focused, cinematic "cockpit" feel.
- **Rhythm:** An 8px base grid governs all padding and margins. Vertical rhythm should be loose (stack-lg) between major sections to prevent the dark UI from feeling claustrophobic.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Luminous Accents** rather than traditional shadows.

1.  **Level 0 (Base):** Deep black (`#0F0F12`) background.
2.  **Level 1 (Panels):** Charcoal (`#1A1A1F`) surfaces with a 1px border of `rgba(255,255,255,0.08)`.
3.  **Level 2 (Interactive):** Elements like the search bar use a slightly lighter fill or a subtle violet inner-glow.
4.  **Backdrop Blurs:** High-priority cards use a 20px blur with a 10% violet tint to appear as if they are floating over a light source.
5.  **Glows:** Active states should trigger an outer "bloom" effect (e.g., the primary button's violet glow) rather than a hard drop shadow.

## Shapes

The shape language is "Rounded" but controlled. It balances the "softness" of modern tech with the "sharpness" of legal precision.

- **Standard Elements:** Buttons, inputs, and chips use a `0.5rem` radius.
- **Large Containers:** Cards and major sections use `1rem` (rounded-lg) or `1.5rem` (rounded-xl) to create a distinct frame for content.
- **Search Inputs:** Should maintain a slightly more rounded profile (pill-inspired) to differentiate "entry" points from "static" data containers.

## Components

### Buttons
- **Primary:** Solid violet background with white text. High-saturation. Add a 12px violet glow on hover.
- **Secondary (Outline):** Emerald border with transparent background. Used for utility demos or "safe" actions.
- **Ghost/Tertiary:** No border, muted gray text, turns white/violet on hover.

### Input Fields
- The primary search/investigate field is a centerpiece. Use a subtle gradient border or a semi-transparent charcoal fill. Icons (Magnifying glass, Paperclip) should be low-opacity until the field is focused.

### Chips/Segments
- Use "Standard," "Quick," "Deep" style chips with a subtle stroke. The active state should have a solid charcoal fill with a violet glow or a high-contrast border to indicate selection.

### Cards/Containers
- Major data blocks should have a distinct charcoal background to separate them from the void of the base UI. Borders should be extremely thin and dark.

### Floating Action Button (FAB)
- Use a circular button with a vibrant gradient (Violet to Lavender) and a "star/sparkle" icon to represent AI features. Apply a heavy 20px blur glow behind it.